package main

import (
	"fmt"
	"os"
	"time"

	"github.com/tebeka/selenium"
)

const (
	port = 8080
)

func main() {
	opts := []selenium.ServiceOption{
		// Enable fake XWindow session.
		// selenium.StartFrameBuffer(),
		selenium.Output(os.Stderr), // Output debug information to STDERR
	}

	// Enable debug info.
	// selenium.SetDebug(true)
	//這裡用相對路徑的方式去寫chromedriver的位置
	service, err := selenium.NewChromeDriverService("/Users/admin/Desktop/projects/go-selenium/chromedriver", port, opts...)
	if err != nil {
		panic(err)
	}

	caps := selenium.Capabilities{"browserName": "chrome"}
	wd, err := selenium.NewRemote(caps, fmt.Sprintf("http://127.0.0.1:%d/wd/hub", port))
	if err != nil {
		panic(err)
	}

	time.Sleep(5 * time.Second)

	if err := wd.Get("https://tw.carousell.com/"); err != nil {
		panic(err)
	}

	// Get a reference to the text box containing code.
	elem, err := wd.FindElement(selenium.ByTagName, "input")
	if err != nil {
		panic(err)
	}

	webElement, err := elem.FindElement(selenium.ByClassName, "D_qP M_mu D_qQ M_mv D_rc D_amV M_aby D_amP M_abs")
	if err != nil {
		return
	}

	err = webElement.SendKeys("mac")
	if err != nil {
		return
	}

	time.Sleep(20 * time.Second)

	err = wd.Quit()
	if err != nil {
		return
	}
	defer func(service *selenium.Service) {
		err := service.Stop()
		if err != nil {
			return
		}
	}(service)
}
