package main

import (
	"github.com/go-vgo/robotgo"
	"time"
)

func main() {
	GetScreen()
}

func Key() {
	time.Sleep(100)
	robotgo.KeyTap("t")
	robotgo.KeyTap("e")
	robotgo.KeyTap("s")
	robotgo.KeyTap("t")
	robotgo.KeyTap("enter")
}

func GetScreen() {
	ok := robotgo.AddEvent("mleft")
	if ok {
		Key()
	}
}
